---
title: "はじめに"
metaTitle: "はじめに"
metaDescription: "SBクラウド、Alibaba Cloud、よくある質問などを紹介します"
---

## はじめに

## Alibaba Cloudとは
AlibabaCloudは中国発サービスで、中国人口が約14億人もいる中で唯一シェアを伸ばしている、APAC's No.1のパブリッククラウドです。
※ガートナー(Gartner)の調査によると、アリババクラウドは世界第3位のIaaSプロバイダーであり、アジア太平洋地域では市場シェア1位のIaaSおよびIUS（インフラストラクチャ・ユーティリティ・サービス）です。
https://www.alibabacloud.com/campaign/apac-number-one

