---
title: "Resource Orchestration Service"
metaTitle: "Resource Orchestration Service（ROS）による構築・運用について"
metaDescription: "Alibab Cloud Terraformによる構築・運用について紹介します"
---

## ROS：Resource Orchestration Service

